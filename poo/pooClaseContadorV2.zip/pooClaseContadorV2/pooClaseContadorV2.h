class Contador {
protected: // Atributos
  int N;
  int limiteSuperior;
  int limiteInferior;
  
public: // Métodos
        Contador(int _N = 0, int li = 0, int ls = 10); // Constructor
  int   GetN();
  void  SetN(int _N);
  void  Incrementar();
  void  Decrementar();
  int   GetLimiteInferior();
  void  SetLimiteInferior(int _limiteInferior);
  int   GetLimiteSuperior();
  void  SetLimiteSuperior(int _limiteSuperior);
  void  Borrar();
};

      Contador::Contador(int _N, int li, int ls)    { N = _N;  limiteInferior = li; limiteSuperior = ls;  }
int   Contador::GetN()                      { return N; }
void  Contador::SetN(int _N)                { if ( (_N >= limiteInferior) && (_N <= limiteSuperior)) N = _N; }
void  Contador::Incrementar()               { if (N < limiteSuperior) N++;      } // N = N + 1
void  Contador::Decrementar()               { if (N > limiteInferior) N--;      } // N = N -1
int   Contador::GetLimiteInferior()         { return limiteInferior; }
void  Contador::SetLimiteInferior(int _limiteInferior) { limiteInferior = _limiteInferior; }
int   Contador::GetLimiteSuperior()                    { return limiteSuperior; }
void  Contador::SetLimiteSuperior(int _limiteSuperior) { limiteSuperior = _limiteSuperior; }
void  Contador::Borrar() { N = 0; }