/* -------------------------------------------
              Clase Barra
   ------------------------------------------- */
class Barra {
protected:
  int valor;
  int maximo;
  int minimo;
  char caracter;

public:  
  Barra(int minimox = 1, int maximox = 10, char caracterx = '*', int valorx = 2);
  int ObtenerValor();
  char ObtenerCaracter();
  int ObtenerMinimo();
  int ObtenerMaximo();
  void CambiarValor(int nuevoVal);
  void CambiarCaracter(char nuevoCar);
  void CambiarMinimo(int nuevoMin);
  void CambiarMaximo(int nuevoMax);
  String Mostrar();
  void Incrementar(int incremento = 1);
  void Decrementar(int decremento = 1);
};

Barra::Barra(int minimox, int maximox, char caracterx, int valorx) {
  valor = valorx;
  maximo = maximox;
  minimo = minimox;
  caracter = caracterx;
}
  
int Barra::ObtenerValor() {
  return valor;
}

char Barra::ObtenerCaracter() {
  return caracter;
}
  
int Barra::ObtenerMinimo() {
  return minimo;
}
  
int Barra::ObtenerMaximo() {
    return maximo;
}
  
void Barra::CambiarValor(int nuevoVal) {
    valor = nuevoVal;
}
  
void Barra::CambiarCaracter(char nuevoCar) {
    caracter = nuevoCar;
}
  
void Barra::CambiarMinimo(int nuevoMin) {
    minimo = nuevoMin;
}
  
void Barra::CambiarMaximo(int nuevoMax) {
    maximo  = nuevoMax;
}
  
String Barra::Mostrar() {
  String cadena = "";
  int i;
    
  for (i = minimo; i <= valor; i++)
      cadena = cadena + caracter;
    
  return cadena;
}
  
void Barra::Incrementar(int incremento) {
  if (valor < maximo) valor = valor + incremento;
}

void Barra::Decrementar(int decremento) {   
  if (valor > minimo) valor = valor - decremento;
}