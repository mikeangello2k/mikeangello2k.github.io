/* ---------------------------------------------
          Clase Interruptor
 ----------------------------------------------- */
class Interruptor {
protected:
int pulsador;              //almacena el estado del botón
int pulsadorAnt;           //almacena el estado anterior del boton
bool estado;
int pinx;
int presionadoNVeces;

public:
  Interruptor(int pinx);
  bool Presionado();
  bool ObtenerEstado();
  int NVecesPresionado();
  void BorrarNVecesPresionado();
};

Interruptor::Interruptor(int piny) {
  pinx = piny;
  pinMode(pinx, INPUT);
  pulsador = 0;
  pulsadorAnt = 0;
  presionadoNVeces = 0;
  estado = false;
}

bool Interruptor::Presionado() {
  bool fuepresionado = false;
  
  pulsador = digitalRead(pinx);
  if ((estado == false) && (pulsador == HIGH) && (pulsadorAnt == LOW)) {
     estado = true;
     delay(40);
  }
  
  if ((estado == true) && (pulsador == LOW) && (pulsadorAnt == HIGH)) {
     estado = false;
     delay(40);
     presionadoNVeces++;
     fuepresionado = true;
  }
  
  pulsadorAnt = pulsador;
  
  return fuepresionado;                                    // regresa el valor de la variable estado 
}

bool Interruptor::ObtenerEstado() {
  return estado;
}

int Interruptor::NVecesPresionado() {
  return presionadoNVeces;
}

void Interruptor::BorrarNVecesPresionado() {
   presionadoNVeces = 0;
   pulsador = 0;
   pulsadorAnt = 0;
   estado = false;
}