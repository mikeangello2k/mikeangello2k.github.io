class Contador {
private: // Atributos
  int N;
  int limiteSuperior;
  int limiteInferior;
  
public: // Métodos
        Contador(int li = 0, int ls = 10); // Constructor
  int   GetN();
  void  SetN(int _N);
  void  Incrementar();
  void  Decrementar();
  int   GetLimiteInferior();
  void  SetLimiteInferior(int _limiteInferior);
  int   GetLimiteSuperior();
  void  SetLimiteSuperior(int _limiteSuperior);
};

      Contador::Contador(int li, int ls)    { N = 0;  limiteInferior = li; limiteSuperior = ls;  }
int   Contador::GetN()                      { return N; }
void  Contador::SetN(int _N)                { if ( (_N >= limiteInferior) && (_N <= limiteSuperior)) N = _N; }
void  Contador::Incrementar()               { if (N < limiteSuperior) N++;      } // N = N + 1
void  Contador::Decrementar()               { if (N > limiteInferior) N--;      } // N = N -1
int   Contador::GetLimiteInferior()         { return limiteInferior; }
void  Contador::SetLimiteInferior(int _limiteInferior) { limiteInferior = _limiteInferior; }
int   Contador::GetLimiteSuperior()                    { return limiteSuperior; }
void  Contador::SetLimiteSuperior(int _limiteSuperior) { limiteSuperior = _limiteSuperior; }