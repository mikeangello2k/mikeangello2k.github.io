/* ---------------------------------------------
          Clase Led
 ----------------------------------------------- */
#define ON    1
#define OFF   0

class Led {
private:
  bool    estado;
  int     pin;
  String  etiqueta;

public:
          Led(int _pin = 13, bool _estado = OFF, String _etiqueta = "No_Definida");
  bool    GetEstado();
  void    SetEstado(bool _estado);
  int     GetPin();
  void    SetPin(int _pin);
  String  GetEtiqueta();
  void    SetEtiqueta(String _etiqueta);
  void    Encender();
  void    Apagar();
};
  
        Led::Led(int _pin, bool _estado, String _etiqueta) { 
            estado = _estado;  pin = _pin; etiqueta = _etiqueta;
            pinMode(pin, OUTPUT);
        }
bool    Led::GetEstado()                    { return estado;                                     }
void    Led::SetEstado(bool _estado)        { estado = _estado; digitalWrite(pin, estado);       }
int     Led::GetPin()                       { return pin;                                        }
void    Led::SetPin(int _pin)               { pin = _pin; pinMode(pin, OUTPUT);                  }
String  Led::GetEtiqueta()                  { return etiqueta;                                   }
void    Led::SetEtiqueta(String _etiqueta)  { etiqueta = _etiqueta;                              }
void    Led::Encender()                     { digitalWrite(pin, ON); estado = ON;                }
void    Led::Apagar()                       { digitalWrite(pin, OFF); estado = OFF;              }