class Contador {
protected: // Atributos
  int N;
  int limiteSuperior;
  int limiteInferior;
  
public: // Métodos
        Contador(int _N = 0, int li = 0, int ls = 10); // Constructor
  int   GetN();
  void  SetN(int _N);
  void  Incrementar();
  void  Decrementar();
  int   GetLimiteInferior();
  void  SetLimiteInferior(int _limiteInferior);
  int   GetLimiteSuperior();
  void  SetLimiteSuperior(int _limiteSuperior);
  void  Borrar();
  void	operator ++();
  void	operator --();
  Contador operator ++ (int);
  Contador operator -- (int);
  Contador operator +  (Contador &);
  Contador operator -  (Contador &);
  Contador operator *  (Contador &);
  Contador operator /  (Contador &);
  bool operator >  (Contador);
  bool operator <  (Contador);
  bool operator == (Contador);
  bool operator >= (Contador);
  bool operator <= (Contador);
  bool operator != (Contador);
  void Print();
};

      Contador::Contador(int _N, int li, int ls)    { N = _N;  limiteInferior = li; limiteSuperior = ls;  }
int   Contador::GetN()                      { return N; }
void  Contador::SetN(int _N)                { if ( (_N >= limiteInferior) && (_N <= limiteSuperior)) N = _N; }
void  Contador::Incrementar()               { 
	  //if (N < limiteSuperior) N++;    
	  N++;
	  if (N > limiteSuperior) N = limiteInferior;  
} // N = N + 1
void  Contador::Decrementar()               { 
	//if (N > limiteInferior) N--; 
	N--;
	if (N < limiteInferior) N = limiteSuperior;     
} // N = N -1
int   Contador::GetLimiteInferior()         { return limiteInferior; }
void  Contador::SetLimiteInferior(int _limiteInferior) { limiteInferior = _limiteInferior; }
int   Contador::GetLimiteSuperior()                    { return limiteSuperior; }
void  Contador::SetLimiteSuperior(int _limiteSuperior) { limiteSuperior = _limiteSuperior; }
void  Contador::Borrar() { N = 0; }
void  Contador::operator ++() { Incrementar(); }
void  Contador::operator --() { Decrementar(); }
Contador Contador::operator ++ (int)             { return Contador(N++); }
Contador Contador::operator -- (int)             { return Contador(N--); }
Contador Contador::operator +  (Contador &CX) { return Contador( N + CX.GetN(), limiteInferior, limiteSuperior); }
Contador Contador::operator -  (Contador &CX) { return Contador( N - CX.GetN(), limiteInferior, limiteSuperior); }
Contador Contador::operator *  (Contador &CX) { return Contador( N * CX.GetN(), limiteInferior, limiteSuperior); }
Contador Contador::operator /  (Contador &CX) { return Contador( N / CX.GetN(), limiteInferior, limiteSuperior); }
  
bool Contador::operator > (Contador CX) {
    if ( N > CX.GetN() )
       return true;
    else 
       return false;
}

bool Contador::operator < (Contador CX) {
    if ( N < CX.GetN() )
       return true;
    else 
       return false;
}

  bool Contador::operator == (Contador CX) {
    if ( N == CX.GetN() )
       return true;
    else 
       return false;
  }

  bool Contador::operator <= (Contador CX) {
    if ( N <= CX.GetN() )
       return true;
    else 
       return false;
  }

  bool Contador::operator >= (Contador CX) {
    if ( N >= CX.GetN() )
       return true;
    else 
       return false;
  }

  bool Contador::operator != (Contador CX) {
    if ( N != CX.GetN() )
       return true;
    else 
       return false;
  }

  void Contador::Print() {
    Serial.print("Valor de N:"); Serial.println(N);
  }