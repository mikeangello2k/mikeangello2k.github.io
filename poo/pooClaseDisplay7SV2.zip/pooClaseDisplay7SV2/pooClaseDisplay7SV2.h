/* --------------------------------------------------------------------------------------------- 
                          Display de 7 Segmentos de CC o AC
   --------------------------------------------------------------------------------------------- */

#define sega  0
#define segb  1
#define segc  2
#define segd  3
#define sege  4
#define segf  5
#define segg  6
#define segp  7

class Display7S {
protected:
  Led  sa,sb,sc,sd,se,sf,sg,sp;
  char caracter;     // 0 .. 9 A b C d E F
  char segmentos[9]; // segmentos[] = "abcdefgp\0"
  char tipo;         // C - CC,    A - AC
  bool punto;
  char salida[9];
  
public:
  Display7S(int pinesSegmentos[8] = {13}, char _tipo = 'C', char _caracter = ' ');
  char GetCaracter();
  void SetCaracter(char _caracter);
  char GetTipo();
  void SetTipo(char _tipo);
  char *GetSegmentos();
  void SetSegmentos(char _segmentos[9]);
  char GetSegmento(int segmento);
  void SetSegmento(int segmento, char valor);
  char GetSega();
  void SetSega(char valor);
  char GetSegb();
  void SetSegb(char valor);
  char GetSegc();
  void SetSegc(char valor);
  char GetSegd();
  void SetSegd(char valor);
  char GetSege();
  void SetSege(char valor);
  char GetSegf();
  void SetSegf(char valor);
  char GetSegg();
  void SetSegg(char valor);
  char GetSegp();
  void SetSegp(char valor);
  bool GetPunto();
  void SetPunto(bool estado);
  bool CharToBool(char segmentox); // char car = '0' --> 80 => 0 - 255   bool var1 => 0 1
  void RepresentarSegmentosCCAC();
  void Borrar();
  int  *GetPines();
  void SetPines(int _pines[8]);
  void Refrescar();
}; 

  Display7S::Display7S(int pinesSegmentos[], char _tipo, char _caracter) {
    String cadena = "00000000";
    tipo = _tipo;
    caracter = _caracter;
    punto = false;
    cadena.toCharArray(segmentos,9); // inicializando el arreglo segmentos con el valor de "00000000"
    sa.SetPin( pinesSegmentos[sega] );
    sb.SetPin( pinesSegmentos[segb] );
    sc.SetPin( pinesSegmentos[segc] );
    sd.SetPin( pinesSegmentos[segd] );
    se.SetPin( pinesSegmentos[sege] );
    sf.SetPin( pinesSegmentos[segf] );
    sg.SetPin( pinesSegmentos[segg] );
    sp.SetPin( pinesSegmentos[segp] );
    // Limpiando el display
    if (tipo == 'C') { // CC
        sa.Apagar();  sb.Apagar();  sc.Apagar();  sd.Apagar();
        se.Apagar();  sf.Apagar();  sg.Apagar();  sp.Apagar();
    } else { // AC
        sa.Encender();  sb.Encender();  sc.Encender();  sd.Encender();
        se.Encender();  sf.Encender();  sg.Encender();  sp.Encender();
    }
  }
  
  char Display7S::GetCaracter() { return caracter; }
  
  void Display7S::SetCaracter(char _caracter) {
    String cadena; 
    caracter = _caracter;
    switch(caracter) {    //abcdefgp
      case '0' :  cadena = "11111100"; break;
      case '1' :  cadena = "01100000"; break;
      case '2' :  cadena = "11011010"; break;
      case '3' :  cadena = "11110010"; break;
      case '4' :  cadena = "01100110"; break;
      case '5' :  cadena = "10110110"; break;
      case '6' :  cadena = "00111110"; break;
      case '7' :  cadena = "11100000"; break;
      case '8' :  cadena = "11111110"; break;
      case '9' :  cadena = "11100110"; break;
      case 'A' :  cadena = "11101110"; break;
      case 'b' :  cadena = "00111110"; break;
      case 'C' :  cadena = "10011100"; break;
      case 'd' :  cadena = "01111010"; break;
      case 'E' :  cadena = "10011110"; break;
      case 'F' :  cadena = "10001110"; break;
      default  :  cadena = "00000000";
    }
    // Convirtiendo una variable tipo String a un arreglo de tipo char
    cadena.toCharArray(segmentos, 9);
    // Comprobar Lógica
    RepresentarSegmentosCCAC();  
    // Encendiendo y Apagando los Leds Asociados al Display
    sa.SetEstado( CharToBool(segmentos[sega]) );
    sb.SetEstado( CharToBool(segmentos[segb]) );
    sc.SetEstado( CharToBool(segmentos[segc]) );
    sd.SetEstado( CharToBool(segmentos[segd]) );
    se.SetEstado( CharToBool(segmentos[sege]) );
    sf.SetEstado( CharToBool(segmentos[segf]) );
    sg.SetEstado( CharToBool(segmentos[segg]) );
    sp.SetEstado( CharToBool(segmentos[segp]) );
  }
  
  char Display7S::GetTipo()                             { return tipo;                }
  
  void Display7S::SetTipo(char _tipo)                   { tipo = _tipo; }
  
  char *Display7S::GetSegmentos()                       { return segmentos;           }
  
  void Display7S::SetSegmentos(char _segmentos[9]) {
    int i;
    for (i = 0; i < 8; i++)
        segmentos[i] = _segmentos[i];
    RepresentarSegmentosCCAC();
    Refrescar();
  }
  
  char Display7S::GetSegmento(int segmento)             { return segmentos[segmento];  }
  
  void Display7S::SetSegmento(int segmento, char valor) { 
    segmentos[segmento] = valor; // char -> 0 255 --- '0'->67->true
    RepresentarSegmentosCCAC(); 
    switch(segmento) {
      case sega : sa.SetEstado( CharToBool(valor) ); break;
      case segb : sb.SetEstado( CharToBool(valor) ); break;
      case segc : sc.SetEstado( CharToBool(valor) ); break;
      case segd : sd.SetEstado( CharToBool(valor) ); break;
      case sege : se.SetEstado( CharToBool(valor) ); break;
      case segf : sf.SetEstado( CharToBool(valor) ); break;
      case segg : sg.SetEstado( CharToBool(valor) ); break;
      case segp : sp.SetEstado( CharToBool(valor) ); break;
    }
  }
  
  char Display7S::GetSega()                             { return segmentos[sega];      }
  
  void Display7S::SetSega(char valor) { 
    segmentos[sega] = valor;
    RepresentarSegmentosCCAC();     
    sa.SetEstado( CharToBool( segmentos[sega] ) ); // sa.SetEstado((bool) segmentos[segmrnto]);
  }
  
  char Display7S::GetSegb()                             { return segmentos[segb];      }
  
  void Display7S::SetSegb(char valor) { 
    segmentos[segb] = valor;
    RepresentarSegmentosCCAC();
    sb.SetEstado( CharToBool( segmentos[segb] ) ); // sb.SetEstado((bool) segmentos[segmrnto]);     
  }
  
  char Display7S::GetSegc()                             { return segmentos[segc];      }
  
  void Display7S::SetSegc(char valor) {
    segmentos[segc] = valor;
    RepresentarSegmentosCCAC();
    sc.SetEstado( CharToBool( segmentos[segc] ) ); // sc.SetEstado((bool) segmentos[segmrnto]);
  }
  
  char Display7S::GetSegd()                             { return segmentos[segd];      }
  
  void Display7S::SetSegd(char valor) {
    segmentos[segd] = valor;
    RepresentarSegmentosCCAC();
    sd.SetEstado( CharToBool( segmentos[segd] ) ); // sd.SetEstado((bool) segmentos[segmrnto]);     
  }
  
  char Display7S::GetSege()                             { return segmentos[sege];      }
  
  void Display7S::SetSege(char valor) {
    segmentos[sege] = valor;
    RepresentarSegmentosCCAC();     
    se.SetEstado( CharToBool( segmentos[sege] ) ); // sa.SetEstado((bool) segmentos[segmrnto]);
  }
  
  char Display7S::GetSegf()                             { return segmentos[segf];      }
  
  void Display7S::SetSegf(char valor) {
    segmentos[segf] = valor;
    RepresentarSegmentosCCAC();
    sf.SetEstado( CharToBool( segmentos[segf] ) ); // sa.SetEstado((bool) segmentos[segmrnto]);
  }
  
  char Display7S::GetSegg()                             { return segmentos[segg];      }
  
  void Display7S::SetSegg(char valor) {
    segmentos[segg] = valor;
    RepresentarSegmentosCCAC();
    sg.SetEstado( CharToBool( segmentos[segg] ) ); // sg.SetEstado((bool) segmentos[segmrnto]);
  }
  
  char Display7S::GetSegp()                             { return segmentos[segp];      }
  
  void Display7S::SetSegp(char valor) {
    segmentos[segp] = valor;
    RepresentarSegmentosCCAC();
    sp.SetEstado((bool) valor); // sp.SetEstado((bool) segmentos[segmrnto]);
  }

  bool Display7S::CharToBool(char segmentox) {
    if (segmentox == '1')
       return true;
    else
       return false;
  }

  void Display7S::RepresentarSegmentosCCAC() {
    int i;
    if (tipo == 'A') { // Ánoco Común, la lógica debe ser inversa a la de Cátodo Común
        for (i = 0; i < 8; i++) {
            if (segmentos[i] == '1')
                segmentos[i]='0';
            else
                segmentos[i] = '1';
        }
    } // fin del if

    if ((punto == true)   && (tipo == 'C'))  segmentos[segp] = '1';
    if ((punto == false)  && (tipo == 'C'))  segmentos[segp] = '0';
    if ((punto == true)   && (tipo == 'A'))  segmentos[segp] = '0';
    if ((punto == false)  && (tipo == 'A'))  segmentos[segp] = '1';
  }

  void Display7S::Borrar() { /* Apaga todos los leds del display */
    if (tipo == 'C')  { // Cátodo Común
        sa.Apagar();  sb.Apagar();  sc.Apagar();  sd.Apagar();
        se.Apagar();  sf.Apagar();  sg.Apagar();  sp.Apagar();
    } else 
      if (tipo == 'A')  { // Ánodo Común
        sa.Encender();  sb.Encender();  sc.Encender();  sd.Encender();
        se.Encender();  sf.Encender();  sg.Encender();  sp.Encender();
      }
  }

  bool Display7S::GetPunto()            { return punto;   }
  
  void Display7S::SetPunto(bool estado) { punto = estado; RepresentarSegmentosCCAC(); }

  int  *Display7S::GetPines() {
      int tmp[8];
      tmp[0] = sa.GetPin();
      tmp[1] = sb.GetPin();
      tmp[2] = sc.GetPin();
      tmp[3] = sd.GetPin();
      tmp[4] = se.GetPin();
      tmp[5] = sf.GetPin();
      tmp[6] = sg.GetPin();
      tmp[7] = sp.GetPin();

      return tmp;
  }
  
  void Display7S::SetPines(int pines[8]) {
    sa.SetPin(pines[sega]);
    sb.SetPin(pines[segb]);
    sc.SetPin(pines[segc]);
    sd.SetPin(pines[segd]);
    se.SetPin(pines[sege]);
    sf.SetPin(pines[segf]);
    sg.SetPin(pines[segg]);
    sp.SetPin(pines[segp]);
  }

  void Display7S::Refrescar() {
      sa.SetEstado( CharToBool( segmentos[sega]) );
      sb.SetEstado( CharToBool( segmentos[segb]) );
      sc.SetEstado( CharToBool( segmentos[segc]) );
      sd.SetEstado( CharToBool( segmentos[segd]) );
      se.SetEstado( CharToBool( segmentos[sege]) );
      sf.SetEstado( CharToBool( segmentos[segf]) );
      sg.SetEstado( CharToBool( segmentos[segg]) );
      sp.SetEstado( CharToBool( segmentos[segp]) );
  }

/* --------------------------------------------------------------------------------------------- */